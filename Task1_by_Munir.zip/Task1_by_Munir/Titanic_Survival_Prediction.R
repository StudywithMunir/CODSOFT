############### Titanic Survival Prediction Model  -By Munir ###############


# Loading necessary libraries
library(ggplot2)
library(randomForest)
library(caret)  # Adding caret for cross-validation

# Reading the Titanic dataset
data <- read.csv("tested.csv")

# Check for missing values
print(colSums(is.na(data)))

# Impute missing values for 'Age' with the mean age
mean_age <- mean(data$Age, na.rm = TRUE)
data$Age[is.na(data$Age)] <- mean_age

mean_fare <- mean(data$Fare, na.rm = TRUE)
data$Fare[is.na(data$Fare)] <- mean_fare

# Encode categorical variables (e.g., Pclass, Sex)
data$Pclass <- as.factor(data$Pclass)
data$Sex <- as.factor(data$Sex)

# Spliting the data into training and testing sets
set.seed(123)  # For reproducibility
train_indices <- sample(1:nrow(data), 0.7 * nrow(data))
train_data <- data[train_indices, ]
test_data <- data[-train_indices, ]

# Feature Engineering
train_data$FamilySize <- train_data$SibSp + train_data$Parch
test_data$FamilySize <- test_data$SibSp + test_data$Parch

# Convert "Survived" to a factor in both training and test datasets
train_data$Survived <- as.factor(train_data$Survived)
test_data$Survived <- as.factor(test_data$Survived)

# Model Building with Hyperparameter Tuning
model <- randomForest(Survived ~ Pclass + Sex + Age + FamilySize + Fare,
                      data = train_data, ntree = 500, mtry = 3, nodesize = 10)

# Cross-Validation (Optional)
control <- trainControl(method = "cv", number = 5)
model_cv <- train(Survived ~ Pclass + Sex + Age + FamilySize + Fare,
                  data = train_data, method = "rf",
                  trControl = control, tuneLength = 3)

# Model Evaluation with Cross-Validation
predictions_cv <- predict(model_cv, newdata = test_data)
confusion_matrix_cv <- table(predictions_cv, test_data$Survived)
accuracy_cv <- sum(diag(confusion_matrix_cv)) / sum(confusion_matrix_cv)

print("Confusion Matrix with Cross-Validation:")
print(confusion_matrix_cv)
print(paste("Accuracy with Cross-Validation:", accuracy_cv))

# Visualization of Survival
ggplot(test_data, aes(x = factor(Survived))) +
  geom_bar(fill = "blue") +
  labs(x = "Survival Status", y = "Count") +
  ggtitle("Distribution of Survival") +
  scale_x_discrete(labels = c("Did not Survive", "Survived"))

# Visualization of Survival by Gender
ggplot(test_data, aes(x = Sex, fill = factor(Survived))) +
  geom_bar(position = "stack") +
  labs(x = "Gender", y = "Count", fill = "Survival Status") +
  ggtitle("Distribution of Survival by Gender") +
  scale_fill_manual(values = c("0" = "red", "1" = "green")) +
  scale_x_discrete(labels = c("Male", "Female"))


############### Task 1 Ended :) ###############
