############### IRIS Classification Model  -By Munir ###############


# Loading required libraries
library(dplyr)
library(ggplot2)
library(caret)
library(randomForest)

# Loading the Iris dataset
iris_data <- read.csv("iris.csv")

# Checking the structure of the dataset
str(iris_data)

# Viewing the first 6 rows of the dataset
head(iris_data)

# Summary statistics of the dataset
summary(iris_data)

# Checking for missing values
any(is.na(iris_data))

# Shuffle the dataset for randomness
set.seed(123)
shuffled_data <- iris_data[sample(nrow(iris_data)), ]

# Spiting the dataset into training (80%) and testing (20%)
train_data <- shuffled_data[1:120, ]
test_data <- shuffled_data[121:150, ]

# Converting the 'species' column to a factor for classification
train_data$species <- as.factor(train_data$species)

# Building a Random Forest classifier
model <- randomForest(species ~ sepal_length + sepal_width + petal_length + petal_width, data = train_data)

# Print model summary
print(model)

# Predict on the test dataset
predictions <- predict(model, newdata = test_data)

# Confusion matrix to evaluate the model
confusion_matrix <- table(predictions, test_data$species)
print(confusion_matrix)

# Calculating accuracy
accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
print(paste("Accuracy:", accuracy))



# Data Visualization using ggplot2

# Feature Importance Plot
library(caret)
importance_df <- as.data.frame(varImp(model))
ggplot(importance_df, aes(x = reorder(rownames(importance_df), -Overall), y = Overall)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  coord_flip() +
  labs(title = "Feature Importance Plot", x = "Feature", y = "Importance")

# Confusion Matrix Plot
confusion_df <- as.data.frame(confusion_matrix)

# Create a data frame for the confusion matrix
confusion_df <- as.data.frame.table(confusion_matrix)
colnames(confusion_df) <- c("Actual", "Predicted", "Freq")

# Confusion Matrix Plot
library(ggplot2)
ggplot(confusion_df, aes(x = Predicted, y = Actual, fill = Freq)) +
  geom_tile() +
  geom_text(aes(label = Freq), vjust = 1) +
  scale_fill_gradient(low = "white", high = "blue") +
  labs(title = "Confusion Matrix", x = "Predicted", y = "Actual")


############### Task 3 Ended :) ###############

