# Loading necessary libraries
library(dplyr)           # Data manipulation
library(randomForest)    # Random forest classifier
library(ROSE)            # Under-sampling for class imbalance
library(caret)           # Model evaluation
library(pROC)            # ROC curve and AUC
library(ggplot2)         # Data visualization

# Loading the dataset
data <- read.csv("creditcard.csv")

# Checking for missing values
missing_values <- sum(is.na(data))
cat("Missing Values Count:", missing_values, "\n")

# Ensure "Class" is a factor or character variable
data$Class <- as.factor(data$Class)

# Normalize transaction amount
data$Amount <- scale(data$Amount)

# Handle class imbalance using under-sampling (ROSE)
data_balanced <- ovun.sample(Class ~ ., data = data, method = "under", N = 2 * sum(data$Class == "1"), seed = 42)$data

# Spiting the dataset into training and testing sets
set.seed(123)
trainIndex <- sample(1:nrow(data_balanced), 0.7 * nrow(data_balanced))
trainData <- data_balanced[trainIndex, ]
testData <- data_balanced[-trainIndex, ]

# Train a random forest classifier
model <- randomForest(Class ~ ., data = trainData)

# Predict on the test set
predictions <- predict(model, newdata = testData)

# Creating a confusion matrix
confusion_matrix <- table(Actual = testData$Class, Predicted = predictions)

# Calculate true positives, false positives, and false negatives
true_positives <- confusion_matrix[2, 2]
false_positives <- sum(confusion_matrix[, 2]) - true_positives
false_negatives <- sum(confusion_matrix[2, ]) - true_positives

# Calculate precision, recall, and F1-Score
precision <- true_positives / (true_positives + false_positives)
recall <- true_positives / (true_positives + false_negatives)
f1_score <- 2 * (precision * recall) / (precision + recall)

# Printing evaluation metrics
cat("Precision:", precision, "\n")
cat("Recall:", recall, "\n")
cat("F1-Score:", f1_score, "\n")

# Visualizing Class Distribution
ggplot(data, aes(x = Class, fill = Class)) +
  geom_bar() +
  labs(title = "Class Distribution",
       x = "Class (0: Genuine, 1: Fraud)",
       y = "Count") +
  theme_minimal()

# Visualizing Amount Distribution
ggplot(data, aes(x = Amount)) +
  geom_histogram(binwidth = 1, fill = "blue") +
  labs(title = "Transaction Amount Distribution",
       x = "Amount",
       y = "Count") +
  theme_minimal()

# Creating a confusion matrix heatmap
heatmap_data <- data.frame(
  Actual = factor(rep(0:1, each = 2), levels = 0:1),
  Predicted = factor(rep(0:1, times = 2), levels = 0:1),
  Count = c(sum(confusion_matrix[1, ]), sum(confusion_matrix[2, ]))
)

ggplot(data = heatmap_data, aes(x = Actual, y = Predicted)) +
  geom_tile(aes(fill = Count), width = 0.5, height = 0.5) +
  geom_text(aes(label = Count), vjust = 1) +
  scale_fill_gradient(low = "white", high = "blue") +
  labs(title = "Confusion Matrix Heatmap",
       x = "Actual",
       y = "Predicted") +
  theme_minimal()
